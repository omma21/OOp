
import java.awt.event.ActionEvent;

public interface ActionListener {
    void actionPerformed(ActionEvent e);

}
